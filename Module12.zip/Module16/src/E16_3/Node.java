package E16_3;

class Node {
    public String data;
    public Node next;
}