package E16_2;

class Node {
    public String data;
    public Node next;
}