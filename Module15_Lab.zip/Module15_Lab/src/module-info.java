module Module15_Lab {
	requires java.desktop;
}