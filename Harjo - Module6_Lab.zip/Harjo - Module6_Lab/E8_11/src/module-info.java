module E8_11 {
	requires java.desktop;
}