package e17_8;


public interface Visitor {
    void visit(Comparable data);
}
