package e17_7;


public interface Visitor {
    void visit(Comparable data);
}
