package e17_9;


public interface Visitor {
    boolean visit(Comparable data);
}
