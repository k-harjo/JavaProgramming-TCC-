package e10_5;

public interface Sequence {
    int next();
}
