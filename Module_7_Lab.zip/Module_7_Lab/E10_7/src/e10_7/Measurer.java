package e10_7;

public interface Measurer {
    double measure(Object anObject);
}
