package p19_5;

public interface WordCollectionADT {
    // Adds a word to the collection.

    void add(String word);

    //Checks if a word is contained in the collection.

    boolean contains(String word);
}
