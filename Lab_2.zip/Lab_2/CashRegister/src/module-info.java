module CashRegister {
}