module MyCashRegister {
}