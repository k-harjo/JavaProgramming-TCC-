module Lab_2 {
}