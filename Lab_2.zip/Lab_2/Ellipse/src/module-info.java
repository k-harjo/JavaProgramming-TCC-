module Ellipse {
}